package com.example.demo.controller;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.*;

@RestController
public class TestResultController {
	@PostMapping("/test_result2")
	public ResponseEntity<String> test2(Test2 dto) {
		System.out.println(dto);
		return null;
	}
	
	@PostMapping("/test_result4_order")
	public ResponseEntity<String> test4_1(MenuDto.InputList dto) {
		System.out.println(dto);
		return null;
	}
	
	@PostMapping("/test_result5_order")
	public ResponseEntity<String> test5_1(MenuDto.InputList dto) {
		System.out.println(dto);
		return null;
	}
}
