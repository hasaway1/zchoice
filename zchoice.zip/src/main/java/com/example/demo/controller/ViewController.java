package com.example.demo.controller;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
public class ViewController {
	@GetMapping("/")
	public String index() {
		return "list";
	}
	
	@GetMapping("/test1")
	public void test1() {
		System.out.println("??????????????????????");
	}
	
	@GetMapping("/test2")
	public void test2() {
	}
	
	@GetMapping("/test3")
	public void test3() {
	}
	
	@GetMapping("/test4")
	public void test4() {
	}
	
	@GetMapping("/test5")
	public void test5() {
	}
}
