package com.example.demo.dto;

import java.util.*;

import lombok.*;

@NoArgsConstructor(access=AccessLevel.PRIVATE)
public class MenuDto {
	@Data
	public static class MenuItem {
		private Integer mno;
		private Integer count;
	}
	
	@Data
	public static class InputList {
		private List<MenuItem> list;
	}
}
